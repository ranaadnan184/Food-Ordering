import React from "react";
import "./App.css";
export default function Card(props) {
  return (
    <div>
      <>
        <div className="container">
          <div>
            <div className="cards">
              <div className="card">
                <img src={props.img} alt="{props.img}" className="cimg" />
                <div className="cinfo">
                  <span className="category">{props.title}</span>
                  <h3 className="title">{props.sname}</h3>
                  <a href={props.Link} target="_blank">
                    <button>Watch Now </button>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    </div>
  );
}
