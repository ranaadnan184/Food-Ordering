import React from 'react'
 import Header from './Header'
 import Card from './Card'
  import Abcd from './Abcd'
 import Form1 from './Form1'
import './App.css'
import {Routes,Route, BrowserRouter as Router,Link} from "react-router-dom";




import About from './About'
import Home from './Home'
 
function App(){
let Asd=[
    {
      img:"amaz.png",
      title:"A Netflix Orignal series",
      sname:"Amazon",
      Link:""
    },
   {
    img:"fiv.png",
    title:"A Netflix Orignal series",
    sname:"Fiver",
    Link:""
   },
   {
    img:"net img 1.jpg",
        title:"A netflix Orignal series",
        sname:"Netflix",
        Link:""
   },
   {
    img:"burger1.jpg",
        title:"Good taste...",
        sname:"Zinger Burger",
        Link:""
   },
   {
    img:"piza1.jpg",
        title:"Good Taste...",
        sname:"Piza",
        Link:""
   }
   ,{
    img:"piza2.jpg",
        title:"Good Taste...",
        sname:"Large Piza",
        Link:""
   },
   {
    img:"handfree1.jpg",
        title:"Handphone Online Shopping",
        sname:"Samsung Handfree",
        Link:""
   },
   {
    img:"handfre2.jpg",
        title:"Handfree Online Shopping",
        sname:"Vivo Handfree",
        Link:""
   },
   {
    img:"handfree3.jpg",
        title:"Handfree Online Shopping",
        sname:"Oppo Brand",
        Link:""
   }
  ] 
  return (
    <div>
      <Router> 
   <Link to='/'>Home</Link>
    <Link to='/About'>About</Link>
    <Link to='/Contact'>Form1</Link>
    
     <Header />
     <Abcd/>
    <Routes>
       <Route exact path="/" element={<Home/>}/>
<Route path="/About" element={<About/>}/>
<Route path="/Contact" element={<Form1/>}/>
</Routes>
    </Router>
    
    {
Asd.map(p=><Card img={p.img} title={p.title} name={p.sname} Link={p.Link}/>)
    }
  
   
    <Card/>
     
   
    </div> 
  
   
  );
}

export default App;
