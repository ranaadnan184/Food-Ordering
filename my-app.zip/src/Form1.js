import React from 'react';
import {Form, Row,Col,} from 'react-bootstrap'
export default function Form1() {
  return (<div>
 <Form>
  <Form.Group as={Row} className="mb-3">
          <Form.Label column sm="2">
            Name
          </Form.Label>
          <Col sm="10">
            <Form.Control Type="text"  />
          </Col>
        </Form.Group>
      
        <Form.Group as={Row} className="mb-3" >
          <Form.Label column sm="2">
            Contact
          </Form.Label>
          <Col sm="10">
            <Form.Control type="Number"/>
          </Col>
        </Form.Group>
      </Form>
      <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
          <Form.Label column sm="2">
            E Mail
          </Form.Label>
          <Col sm="10">
            <Form.Control plaintext readOnly defaultValue="email@example.com" />
          </Col>
        </Form.Group>
        <Form.Group as={Row} className="mb-3" >
          <Form.Label column sm="2">
            Address
          </Form.Label>
          <Col sm="10">
            <Form.Control Type="text"  />
          </Col>
        </Form.Group>
      <Form>
        <Form.Check 
          type="switch"
          id="custom-switch"
          label="Check this switch"
        />
        <Form.Check 
          disabled
          type="switch"
          label="disabled switch"
          id="disabled-custom-switch"
        />
      </Form>
  </div>)
}
