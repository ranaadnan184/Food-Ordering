import React from 'react';

export default function Checkout() {
  return( <form>
      <section className="Registration">
      <div>
      <lable className="fname">
      <i class="zmdi zmdi-account">First Name
      </i></lable>
      <input type="text" placeholder="Fist Name"name="first name" autoComplete></input>
      <lable>
      <i class="zmdi zmdi-account"></i> Last Name </lable>
      <input type="text" placeholder="Last Name"name="last name" autoComplete></input>
  </div> <br/>


     <div>
      <lable>
      <i class="zmdi zmdi-email"></i>
      E Mail
      </lable>
      <input type="email" placeholder="E mail" name="E mail" autoComplete="off"></input>
     </div><br/>
     <div>
      <lable>
      <i class="zmdi zmdi-phone-in-talk"></i>Contact</lable>
      <input type="tel" placeholder="contact"name="contact" autoComplete="off"></input>
     </div><br/>
     <div>
      <lable>
      <i class="zmdi zmdi-address"></i>Address</lable>
      <input type="text" placeholder="Adress"name="contact" autoComplete="off"></input>
     </div>
     <div>
      <lable> <i class="zmdi zmdi-Lock"></i>Password
      </lable>
      <input type="password" placeholder="Password" name="password" autoComplete="off"></input>
     </div><br/>
     <div>
      <lable> <i class="zmdi zmdi-Lock"></i>Confirm Password
      </lable>
      <input type="password" placeholder="Confirm Password" name="cpassword" autoComplete="off"></input>
     </div><br/>
     <div>
         <input type="submit" name="singup" className="submit">Submit</input>
     </div>
      </section>
  </form>
  )
}
