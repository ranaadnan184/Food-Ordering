import React from 'react';

export default function Home() {
  return( <div>
      <h1>Rajput</h1>
  </div>)
}
