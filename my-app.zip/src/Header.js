import React from 'react'
import './App.css'
import {Navbar ,Container ,Nav ,NavDropdown , Form ,FormControl, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
export default function Header() {
    return (
        <Navbar bg="black" expand="lg">
        <Container fluid>
          <Navbar.Brand href="#">Navbar scroll</Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="navbarScroll">
            <Nav
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: '100px' }}
              navbarScroll
            >
            
              <Link exact to="/Home">Home</Link>
              <Link exact to="/About">About</Link>
              <NavDropdown title="Others" id="navbarScrollingDropdown">
                <Link to="/Form1">Contact</Link><br/>
                <Link exact to="/Services">Services</Link>
                <NavDropdown.Divider />
                <Link to="#action5">
                  Gellery
                </Link>
              </NavDropdown>
              <Link to="#" disabled>
                Discription
              </Link>
            </Nav>
            <Form className="d-flex">
              <FormControl
                type="search"
                placeholder="Search"
                className="me-2"
                aria-label="Search"
              />
              <Button variant="outline-success">Search</Button>
            </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>
             
    )
    
}
//         <div className="Styles">
//         <nav className="navbar navbar-expand-lg navbar-light bg-light">
//     <div className="container-fluid">
//       <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
//         <span className="navbar-toggler-icon"></span>
//       </button>
//       <div className="collapse navbar-collapse" id="navbarTogglerDemo01">
//         <a className="navbar-brand" href="#">Hidden brand</a>
//         <ul className="navbar-nav me-auto mb-2 mb-lg-0">
//           <li className="nav-item">
//             <a className="nav-link active" aria-current="page" href="#">Home</a>
//           </li>
//           <li className="nav-item">
//             <a className="nav-link" href="#">Link</a>
//           </li>
//           <li className="nav-item">
//             <a className="nav-link disabled">Disabled</a>
//           </li>
//         </ul>
//         <form class="d-flex">
//           <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
//           <button className="btn btn-outline-success" type="submit">Search</button>
//         </form>
//       </div>
//     </div>
//   </nav>
//   </div>     
 

